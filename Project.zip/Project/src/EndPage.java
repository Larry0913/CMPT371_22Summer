import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;

import static java.awt.Color.*;

public class EndPage{

    JFrame ep = new JFrame("Result");
    JLabel Your_Color = new JLabel("Your Color ");
    JLabel Color = new JLabel();
    JLabel Your_Rank = new JLabel("Your Rank");
    JLabel Rank = new JLabel();
    JLabel Your_Score = new JLabel("Your Score");
    JLabel Score = new JLabel();
    JLabel Winner = new JLabel("!Champion!");
    JLabel Winner_Color = new JLabel();
    Color winner;

    EndPage(java.awt.Color Y, String your_rank, String your_score , String C){
        ep.addWindowListener(new WindowAdapter(){
            public void windowClosing(WindowEvent e){
                // TODO: close connection here
                System.out.println("============================");
                int i=JOptionPane.showConfirmDialog(ep,"Do you want to quit?","Exit Confirmation", JOptionPane.YES_NO_OPTION);
                if(i == JOptionPane.YES_OPTION) {
                    ep.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                }
                else if (i == JOptionPane.NO_OPTION)
                    ep.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
            }
        });

        if(C.equals("green"))
        {
            winner = green;
        }

        else if(C.equals("red"))
        {
            winner = red;
        }
        else if(C.equals("yellow"))
        {
            winner = yellow;
        }
        else if(C.equals("blue"))
        {
            winner = blue;
        }

        ep.setSize(1000,1000);
        ep.setResizable(false);

        ep.setLayout((null));

        Your_Color.setLocation(125, 650);
        Your_Color.setSize(150, 75);
        Your_Color.setFont(new Font("", Font.BOLD, 24));
        Your_Color.setHorizontalAlignment(JLabel.CENTER);

        Color.setLocation(150, 725);
        Color.setSize(100, 100);
        Color.setOpaque(true);
        Color.setBackground(Y);

        Your_Rank.setLocation(425, 650);
        Your_Rank.setSize(150, 75);
        Your_Rank.setFont(new Font("", Font.BOLD, 24));

        Rank.setLocation(425, 725);
        Rank.setSize(150, 150);
        Rank.setText(your_rank);
        Rank.setFont(new Font("Ink Free", Font.BOLD, 90));
        Rank.setHorizontalAlignment(JLabel.CENTER);

        Your_Score.setLocation(700, 650);
        Your_Score.setSize(150, 75);
        Your_Score.setFont(new Font("", Font.BOLD, 24));

        Score.setLocation(700, 725);
        Score.setSize(150, 150);
        Score.setText(your_score);
        Score.setFont(new Font("Ink Free", Font.BOLD, 90));
        Score.setHorizontalAlignment(JLabel.CENTER);

        Winner.setLocation(45, 100);
        Winner.setSize(900, 100);
        Winner.setFont(new Font("", Font.BOLD, 48));
        Winner.setHorizontalAlignment(JLabel.CENTER);

        Winner_Color.setLocation(350, 250);
        Winner_Color.setSize(300, 300);
        Winner_Color.setOpaque(true);
        Winner_Color.setBackground(winner);

        ep.add(Your_Color);
        ep.add(Color);
        ep.add(Your_Rank);
        ep.add(Rank);
        ep.add(Your_Score);
        ep.add(Score);
        ep.add(Winner_Color);
        ep.add(Winner);

        ep.setVisible(true);
    }

}
